import 'package:flutter_test/flutter_test.dart';
import 'package:daftarkar_man/main.dart';

void main() {
  test('money formatter returns a string', () {
    expect(money(1200), isA<String>());
  });
}
